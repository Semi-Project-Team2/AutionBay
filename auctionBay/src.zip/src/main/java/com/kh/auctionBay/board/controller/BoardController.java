package com.kh.auctionBay.board.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.kh.auctionBay.board.model.dto.BoardDTO;
import com.kh.auctionBay.board.model.dto.BoardListResult;
import com.kh.auctionBay.board.model.dto.BoardSearchCondition;
import com.kh.auctionBay.board.model.dto.CommentDTO;
import com.kh.auctionBay.board.service.BoardService;
import com.kh.auctionBay.board.service.CommentService;
import com.kh.auctionBay.common.SessionConst;
import com.kh.auctionBay.common.dto.ApiResponse;
import com.kh.auctionBay.product.model.dto.ProductDTO;
import com.kh.auctionBay.product.service.ProductService;
import com.kh.auctionBay.review.model.dto.ReviewDTO;
import com.kh.auctionBay.review.model.dto.ReviewSummaryDTO;
import com.kh.auctionBay.review.model.dto.SearchCondition;
import com.kh.auctionBay.review.service.ReviewService;
import com.kh.auctionBay.user.model.dto.UserDTO;

import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;

@Controller
@RequestMapping("/board")
@RequiredArgsConstructor
public class BoardController {
    
    private final BoardService service;
    private final CommentService commentService;
    private final ReviewService reviewService;
    private final ProductService productService;
    
    // ------- 게시글 목록 ---------
    @GetMapping("/list")
    public String boardList(@ModelAttribute BoardSearchCondition condition, Model model) {
        BoardListResult result = service.getBoardList(condition);
        model.addAttribute("boardList", result.getBoardList());
        model.addAttribute("pageInfo", result.getPageInfo());
        model.addAttribute("condition", condition);
    
        return "board/list";
    }
    
    // ------- 게시글 작성 ---------
    @GetMapping("/write")
    public String writeForm() {
        return "board/form";
    }
    
    @PostMapping("/write")
    public String write(@ModelAttribute BoardDTO board,
                        @RequestParam(value="imageFiles", required=false) List<MultipartFile> images,
                        HttpSession session) throws IllegalStateException, IOException {
        UserDTO loginUser = (UserDTO) session.getAttribute(SessionConst.LOGIN_USER);
        if (loginUser != null) {
            board.setMemberId(loginUser.getUserId());
        }
        
        service.writeBoard(board, images);
        return "redirect:/board/list";
    }
    
    // ------- 게시글 상세 조회 ---------
    @GetMapping("/{productId}/detail")
    public String boardDetail(@PathVariable("productId") Long productId, Model model, HttpSession session, SearchCondition condition) {

    	// 1. 상품정보 조회용
    	ProductDTO product = productService.getProductByProductId(productId);
        
        // 2. 댓글 목록 가져오기 (Long 타입 productId 전달)
        List<CommentDTO> comments = commentService.getComments(productId);
    	model.addAttribute("comments", comments);
        
        // 3. 로그인 회원 작성자 여부 체크
        UserDTO loginUser = (UserDTO) session.getAttribute(SessionConst.LOGIN_USER);
        
        boolean isOwner = false;
        if (loginUser != null && product != null) {
            if (loginUser.getUserNo() != null && loginUser.getUserNo().equals(product.getWriterNo())) {
                isOwner = true;
            }
        }
        
        // 리뷰 정보 조회 (product가 존재할 때만 실행)
        ReviewSummaryDTO rs = null;
        List<ReviewDTO> reviewList = null;
        if (product != null && product.getWriterNo() != null) {
            rs = reviewService.getAvgAndCountReview(product.getWriterNo());
            condition.setUserNo(product.getWriterNo());
            reviewList = reviewService.getReceivedReviews(condition).getReviews();
        }
 		
		// 찜 여부 조회
    	boolean isLiked = false;
		if (loginUser != null) {
			isLiked = service.checkIsLiked(loginUser.getUserNo(), productId);
		}
		
		model.addAttribute("product", product);
		model.addAttribute("isOwner", isOwner);
		model.addAttribute("isLiked", isLiked);
		model.addAttribute("reviewSummary", rs);
		model.addAttribute("reviewList", reviewList);
		
		return "board/detail";
    }
    
    // ------- 게시글 수정 화면 이동 ---------
    @GetMapping("/update/{productId}")
    public String updateForm(@PathVariable("productId") Long productId, Model model, HttpSession session) {
        BoardDTO board = service.getBoardDetail(productId);
        UserDTO loginUser = (UserDTO) session.getAttribute(SessionConst.LOGIN_USER);

        if (loginUser == null) {
            return "redirect:/login";
        }

        if (board == null || !loginUser.getUserId().equals(board.getMemberId())) {
            return "redirect:/board/" + productId + "/detail";
        }

        model.addAttribute("board", board);
        return "board/updateForm";
    }

    // ------- 게시글 수정 처리 ---------
    // ★ URL 매핑을 /update/{productId}로 변경하여 PathVariable 명칭 통일
    @PostMapping("/update/{productId}")
    public String update(@PathVariable("productId") Long productId,
                         @ModelAttribute BoardDTO board,
                         @RequestParam(value="imageFiles", required=false) List<MultipartFile> images,
                         HttpSession session) throws IllegalStateException, IOException {

        UserDTO loginUser = (UserDTO) session.getAttribute(SessionConst.LOGIN_USER);
        BoardDTO originalBoard = service.getBoardDetail(productId);

        if (loginUser == null || originalBoard == null || !loginUser.getUserId().equals(originalBoard.getMemberId())) {
            return "redirect:/board/" + productId + "/detail";
        }

        board.setBoardId(productId);
        board.setMemberId(loginUser.getUserId());
        board.setWriterNo(loginUser.getUserNo());

        service.updateBoard(board, images);
        return "redirect:/board/" + productId + "/detail";
    }

    // ------- 게시글 삭제 ---------
    @DeleteMapping("/{productId}")
    @ResponseBody
    public ResponseEntity<ApiResponse<Long>> deleteBoard(@PathVariable("productId") Long productId,
                                                         HttpSession session) {
        UserDTO loginUser = (UserDTO) session.getAttribute(SessionConst.LOGIN_USER);

        if (loginUser == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(ApiResponse.fail("로그인이 필요합니다."));
        }

        try {
            service.deleteBoard(productId);
            return ResponseEntity.status(HttpStatus.OK).body(ApiResponse.success("성공적으로 삭제하였습니다", productId));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ApiResponse.fail(e.getMessage()));
        } catch (SecurityException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(ApiResponse.fail(e.getMessage()));
        }
    }
}